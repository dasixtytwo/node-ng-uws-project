module.exports = {
  HOST: "b00351081_admin@cluster0.7h9x0.mongodb.net",
  DB: "cluster0?retryWrites=true&w=majority"
};
