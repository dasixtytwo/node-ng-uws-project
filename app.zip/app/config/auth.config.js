module.exports = {
  secret: "groupd-secret-key"
};